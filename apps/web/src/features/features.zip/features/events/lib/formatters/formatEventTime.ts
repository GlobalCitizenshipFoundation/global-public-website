const DEFAULT_LOCALE = 'en-GB' as const;
const DEFAULT_TIMEZONE = 'Europe/Warsaw' as const;

type DateInput = string | number | Date;

function toValidDate(input: DateInput): Date | null {
  const date = input instanceof Date ? input : new Date(input);
  return Number.isNaN(date.getTime()) ? null : date;
}

const timeFormatter = new Intl.DateTimeFormat(DEFAULT_LOCALE, {
  hour: '2-digit',
  minute: '2-digit',
  hour12: false,
  timeZone: DEFAULT_TIMEZONE,
});

/**
 * "14:05"
 */
export function formatEventTime(input: DateInput): string {
  const date = toValidDate(input);
  if (!date) return '';
  return timeFormatter.format(date);
}
