import React from 'react';
import Image from 'next/image';

type Props = {
  imageUrl: string | null;
  alt: string;
};

export default function Hero({ imageUrl, alt }: Props) {
  return (
    <div className="mb-10">
      <div
        className={[
          'relative right-1/2 left-1/2 -mr-[50vw] -ml-[50vw] w-[100dvw]',
          'lg:static lg:right-auto lg:left-auto lg:mr-0 lg:ml-0 lg:w-full',
        ].join(' ')}
      >
        <div className="relative aspect-[16/9] w-full overflow-hidden rounded-none xl:rounded-[10px]">
          {imageUrl ? (
            <Image
              src={imageUrl}
              alt={alt}
              fill
              sizes="(max-width: 1200px) 100vw, 1050px"
              className="object-cover"
              priority
            />
          ) : (
            <div className="flex h-full w-full items-center justify-center border border-white/10 bg-black/25">
              <span className="text-borders/80 text-sm font-medium">No image</span>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
