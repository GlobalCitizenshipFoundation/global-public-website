import React from 'react';
import { PortableText } from '@portabletext/react';
import type { EventSingleType } from '@gcf/types';

import ContributorFrame from '@/features/contributors/ui/ContributorFrame';

import SectionHeading from '../components/SectionHeading';
import { portableTextComponents } from '../../lib/portableTextComponents';

type Props = {
  heading: string;
  text?: EventSingleType['speakersText'] | EventSingleType['steeringCommitteeText'];
  people: Array<{ _id: string }>;
};

export default function PeopleSection({ heading, text, people }: Props) {
  const hasText = Boolean(text?.length);
  const hasPeople = people.length > 0;

  if (!hasText && !hasPeople) return null;

  return (
    <section className="mb-12 flex flex-col lg:mb-20">
      <div className="mb-11 flex flex-col">
        <SectionHeading>{heading}</SectionHeading>
        {hasText ? <PortableText value={text!} components={portableTextComponents} /> : null}
      </div>

      {hasPeople ? (
        <div className="flex flex-wrap gap-x-4.5 gap-y-18">
          {people.map((p) => (
            <ContributorFrame contributor={p} key={p._id} />
          ))}
        </div>
      ) : null}
    </section>
  );
}
