import React from 'react';
import { PortableText } from '@portabletext/react';
import type { EventSingleType } from '@gcf/types';

import { portableTextComponents } from '../../lib/portableTextComponents';

type Props = {
  heading: string;
  description?: EventSingleType['agendaDescription'];
  agenda?: EventSingleType['agenda'];
};

export default function Agenda({ heading, description, agenda }: Props) {
  const showDescription = Boolean(description?.length);
  const showAgenda = Boolean(agenda?.length);

  return (
    <section className="mb-14 flex flex-col gap-1.5">
      <h2 className="text-titles mb-0 text-2xl lg:mb-4.5 lg:text-[42px]">{heading}</h2>

      {showDescription ? (
        <PortableText value={description!} components={portableTextComponents} />
      ) : null}

      {showAgenda ? (
        <div className="mt-6 flex flex-col gap-6">
          {agenda!.map((day) => (
            <div key={day._key} className="flex flex-col gap-3">
              <div className="text-titles text-lg font-semibold">{day.date}</div>

              <div className="flex flex-col gap-4">
                {day.sessions.map((s) => (
                  <div key={s._key} className="border-lines border-b pb-4">
                    <div className="text-titles text-base font-semibold lg:text-xl">{s.title}</div>
                    <div className="text-borders text-sm lg:text-lg">
                      {new Date(s.startAt).toLocaleTimeString()} -{' '}
                      {new Date(s.endAt).toLocaleTimeString()}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      ) : null}
    </section>
  );
}
