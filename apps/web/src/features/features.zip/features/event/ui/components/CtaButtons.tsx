import React from 'react';
import Link from 'next/link';

import type { EventSingleType } from '@gcf/types';
import { isValidHttpUrl } from '../../lib/isValidHttpUrl';

type Props = {
  secondary?: EventSingleType['buttonSecondary'];
  tertiary?: EventSingleType['buttonTertiary'];
};

export default function CtaButtons({ secondary, tertiary }: Props) {
  const buttons = [
    { variant: 'secondary' as const, data: secondary },
    { variant: 'tertiary' as const, data: tertiary },
  ].filter((x) => x.data?.label && isValidHttpUrl(x.data?.url));

  if (!buttons.length) return null;

  return (
    <div className="mb-11 flex w-full flex-col gap-4">
      {buttons.map(({ variant, data }, idx) => {
        const label = data!.label!;
        const url = data!.url!;
        const isFirst = idx === 0;

        const containerClass = [
          'flex h-11 w-full items-center justify-center rounded-lg transition-all duration-300',
          isFirst ? 'bg-white hover:bg-purple-400' : 'bg-gray hover:bg-purple-400',
        ].join(' ');

        const labelClass = isFirst
          ? 'text-black text-base font-medium'
          : 'text-white text-base font-medium';

        return (
          <Link
            key={`${variant}-${url}`}
            href={url}
            target="_blank"
            rel="noreferrer"
            className={containerClass}
          >
            <span className={labelClass}>{label}</span>
          </Link>
        );
      })}
    </div>
  );
}
