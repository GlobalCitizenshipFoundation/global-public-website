import type React from 'react';

import { PeoplePhotos } from '../ui/sections/PeoplePhotos';
import { PanelDiscussion } from '../ui/sections/PanelDiscussion';
import ContributorFrame from '@/features/contributors/ui/ContributorFrame';
import type { EventPartnerGroup, EventLifecycleStatus } from '@gcf/types';
import type { getSocialLinksFromCMS } from '@/features/social/ui/getSocialMediaFromCMS';

type People = React.ComponentProps<typeof PeoplePhotos>['people'];
type PanelBase = Omit<React.ComponentProps<typeof PanelDiscussion>, 'pricing' | 'price'>;
type Contributor = React.ComponentProps<typeof ContributorFrame>['contributor'];

export type EventSingleVM = {
  speakers: Contributor[];
  steering: Contributor[];
  combinedParticipants: People;

  lifecycleStatus: EventLifecycleStatus;
  socialLinks: ReturnType<typeof getSocialLinksFromCMS>;
  partnerGroups: EventPartnerGroup[];

  headings: {
    intro: string;
    video: string;
    body: string;
    agenda: string;
    partners: string;
    registration: string;
    speakers: string;
    steering: string;
  };

  show: {
    intro: boolean;
    video: boolean;
    body: boolean;
    agenda: boolean;
    topics: boolean;
    registration: boolean;
  };

  panelBase: PanelBase;

  hero: {
    imageUrl: string | null;
    alt: string;
  };
};
