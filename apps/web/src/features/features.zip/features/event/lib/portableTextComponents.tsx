import React from 'react';
import type { PortableTextComponents } from '@portabletext/react';

export const portableTextComponents: PortableTextComponents = {
  block: {
    h2: ({ children }) => <h2 className="text-titles text-2xl lg:text-[42px]">{children}</h2>,
    h3: ({ children }) => (
      <h3 className="text-titles text-xl font-semibold lg:text-3xl">{children}</h3>
    ),
    normal: ({ children }) => <p className="text-body text-sm lg:text-2xl">{children}</p>,
  },
};
